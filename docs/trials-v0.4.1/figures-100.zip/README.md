# 100 幅独立绘制的科研图例 / 100 independently drawn scientific figures

打开 `cases.csv`，按案例编号查找作品、题名、期刊、论文 DOI、来源链接、图中显示范围和文件 SHA-256。CSV 使用带 BOM 的 UTF-8 编码，可用 Excel 打开。每个案例对应一篇不同的原始研究论文。

| 案例 | 文件 | 阅读方式 |
| --- | --- | --- |
| D001–D048 | 48 幅矢量 PDF | 使用作者公开的 Source Data 工作簿重新绘制一组横、纵列。CSV 给出工作表、单元格范围、所选系列、数据行数与显示窗口。部分窗口限于前 600 行，峰值或阈值标注的解释范围以该窗口为准。 |
| S001–S039 | 39 张可编辑 PPTX | 根据指定论文面板与图注独立设计的概念示意图。CSV 给出面板和功能、状态或部件。可在演示软件中展开分组编辑形状和文字。示意尺寸、物体数量和角度只在原始文献明确时才具备定量含义。 |
| A001–A013 | 13 幅矢量 PDF | 由 NASA Exoplanet Archive 的 Planetary Systems 表按论文 bibcode 筛选。仅显示轨道周期、选定参数及其上下误差完整且无限值标记的解。各点和纵向误差棒的意义见 CSV 与原文。 |

这些图可用于练习绘图、评估标注与比较可编辑性。引用研究结论或复用数据时，请引用相应原论文和数据提供者，并查阅其条款。构图、显示窗口和标注是本次案例的选择，解释结果时请保留来源记录。包内材料为本次独立绘制的成品和来源目录。

## English

Look up the case ID in `cases.csv` for the finished file, article, DOI, source URL, displayed window, and SHA-256. Each of the 100 cases refers to a distinct original research article.

- **D001–D048, vector PDF.** Each graph replots designated cells from a publicly released author workbook. The catalog identifies the worksheet, cell range, series, row count, and window. Several graphs use the first 600 consecutive numeric rows. Interpret a marked extremum or threshold within the specified range.
- **S001–S039, editable PowerPoint.** Each slide independently illustrates the concepts described in the cited figure panel and caption using native shapes and text. Grouped elements can be edited. Counts, angles, and distances are illustrative unless supported by the cited work.
- **A001–A013, vector PDF.** These plots use published planetary parameters retrieved through the NASA Exoplanet Archive. Each case identifies the paper's bibliographic code and the fields plotted. The retained solutions have a period, a central value, and both uncertainties, with limit flags excluded. Vertical bars show the reported upper and lower errors.

The collection supports plotting practice and evaluation of figure construction and annotation. For reuse of research data or claims, credit the associated paper and provider and consult their terms. The displayed windows, layout and annotation choices belong to these examples.

The A cases use the NASA Exoplanet Archive, operated by the California Institute of Technology under NASA contract through the Exoplanet Exploration Program. Cite the original paper listed for the case as well as the archive. [Planetary Systems dataset](https://doi.org/10.26133/NEA12) · [Christiansen et al. (2025)](https://doi.org/10.3847/PSJ/ade3c2) · [Archive acknowledgments](https://exoplanetarchive.ipac.caltech.edu/docs/acknowledge.html)
